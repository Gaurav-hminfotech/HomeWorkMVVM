package com.imaginato.homeworkmvvm.ui.login

import android.app.Activity
import androidx.lifecycle.Observer
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.Toast
import com.imaginato.homeworkmvvm.R
import com.imaginato.homeworkmvvm.data.remote.login.request.LoginRequest
import com.imaginato.homeworkmvvm.data.remote.login.response.Data
import com.imaginato.homeworkmvvm.databinding.ActivityLoginBinding
import com.imaginato.homeworkmvvm.ui.LoginActivityViewModel
import org.koin.core.component.KoinApiExtension

import org.koin.androidx.viewmodel.ext.android.viewModel


@KoinApiExtension
class LoginActivity : AppCompatActivity() {

    private val loginViewModel by viewModel<LoginActivityViewModel>()
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = binding.edtUsername
        val password = binding.edtPassword
        val login = binding.login
        val loading = binding.pbLoading



        loginViewModel.loginFormState.observe(this@LoginActivity, Observer {
            val loginState = it ?: return@Observer

            // disable login button unless both username / password is valid
            login.isEnabled = loginState.isDataValid

            if (loginState.usernameError != null) {
                username!!.error = getString(loginState.usernameError)
            }
            if (loginState.passwordError != null) {
                password!!.error = getString(loginState.passwordError)
            }
        })

        loginViewModel.resultLiveData.observe(this@LoginActivity, Observer {
            val loginResult = it ?: return@Observer

            loading!!.visibility = View.GONE
            if (!loginResult.errorCode.equals("00")) {
                showLoginFailed(loginResult.errorMessage!!)
            } else {
                updateUiWithUser(loginResult.data)
            }
            setResult(Activity.RESULT_OK)

            //Complete and destroy login activity once successful
//            finish()
        })

        username?.afterTextChanged {
            loginViewModel.loginDataChanged(
                username!!.text.toString(),
                password!!.text.toString()
            )
        }

        password?.apply {
            afterTextChanged {
                loginViewModel.loginDataChanged(
                    username!!.text.toString(),
                    password!!.text.toString()
                )
            }

            setOnEditorActionListener { _, actionId, _ ->
                when (actionId) {
                    EditorInfo.IME_ACTION_DONE ->
                        loginViewModel!!.getLoginData(
                            LoginRequest(username!!.text.toString(), password!!.text.toString())

                        )
                }
                false
            }

            login.setOnClickListener {
                loading!!.visibility = View.VISIBLE
                loginViewModel!!.getLoginData(
                    LoginRequest(username!!.text.toString(), password!!.text.toString())

                )
            }
        }
    }

    private fun updateUiWithUser(model: Data?) {
        val welcome = getString(R.string.welcome)
        val displayName = model!!.userName
        // TODO : initiate successful logged in experience
        Toast.makeText(
            applicationContext,
            "$welcome $displayName",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showLoginFailed(errorString: String) {
        Toast.makeText(applicationContext, errorString, Toast.LENGTH_SHORT).show()
    }
}

/**
 * Extension function to simplify setting an afterTextChanged action to EditText components.
 */
fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(editable: Editable?) {
            afterTextChanged.invoke(editable.toString())
        }

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
    })
}