package com.imaginato.homeworkmvvm.data.remote.login

import com.imaginato.homeworkmvvm.data.remote.login.request.LoginRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.Dispatcher
import retrofit2.await


class LoginDataRepository constructor(
    private var api: LoginApi
) : LoginRepository {
    companion object {

        fun getHeaders() : HashMap<String, String>
        {
            var headers = HashMap<String, String>()
            headers["IMSI"] = "357175048449937"
            headers["IMEI"] = "510110406068589"
            return headers
        }
    }
    override suspend fun getLoginData(loginRequest: LoginRequest)= flow {
        val response = api.login(loginRequest, getHeaders()).await()
        emit(response)
    }.flowOn(Dispatchers.IO)
}