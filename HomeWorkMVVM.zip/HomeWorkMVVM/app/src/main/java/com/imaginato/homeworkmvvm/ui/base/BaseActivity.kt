package com.imaginato.homeworkmvvm.ui.base

import androidx.appcompat.app.AppCompatActivity

open class BaseActivity: AppCompatActivity() {

}