package com.imaginato.homeworkmvvm.ui.base

import androidx.fragment.app.Fragment

class BaseFragment: Fragment() {
}