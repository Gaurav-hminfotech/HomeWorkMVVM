package com.imaginato.homeworkmvvm.domain

import org.koin.core.component.KoinApiExtension
import org.koin.core.component.KoinComponent

@KoinApiExtension
interface BaseUseCase: KoinComponent